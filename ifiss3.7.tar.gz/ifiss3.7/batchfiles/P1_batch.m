1     % problem
4     % grid parameter
1     % uniform/stretched grid
2     % domain size
1     % approximation
0     % nonreference solution

%% Data file for test problem P1 
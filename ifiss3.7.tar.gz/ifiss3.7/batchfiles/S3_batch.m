3     % problem
3     % cavity type
6     % grid parameter
2     % uniform/stretched grid
4     % discretisation
2     % uniform/exponential streamlines

%% Data file for test problem S3

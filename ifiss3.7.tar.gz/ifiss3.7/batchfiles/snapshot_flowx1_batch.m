10    % snapshot time
1e-6  % stopping tolerance
30    % maximum number of iterations
4     % PCD* preconditioner
2     % AMG
2     % ILU smoothing on the finest level
1     % figure number
1     % color 

%% Data file for snapshot solution of NS demo problem 

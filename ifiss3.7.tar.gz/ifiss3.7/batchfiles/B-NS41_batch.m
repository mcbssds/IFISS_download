2     % problem
1     % H
4     % L
1     % uniform grid 
20    % number of elements in y-direction
4     % multiplication factor
2     % node enumeration
1     % adiabatic temperature BC
3000  % Ra
0.015 % Pr
200   % target time
5     % nmax (200 time steps)
3e-5  % time accuracy tolerance
0     % number of Picard steps
10    % time averaging frequency
1     % solution plot switch
5     % plotting frequency
16    % frame rate
2     % profile x coordinate
0.5   % profile y coordinate
1     % generate point history 
0.1   % x1
0.1   % y1
0.1   % x2
0.9   % y2 
13    % timestep evolution figure number

%% Data file for test problem 4.2 

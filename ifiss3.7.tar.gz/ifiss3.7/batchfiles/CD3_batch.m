3     % problem
4     % grid parameter
1     % uniform/stretched grid
0.005 % viscosity parameter
inf   % SUPG parameter (inf==>optimal)

%% Data file for test problem CD3

25    % snapshot time
1e-8  % stopping tolerance
30    % maximum number of iterations
9     % PCD* preconditioner
2     % AMG
1     % compute AMG data
2     % ILU smoothing on the finest level
19    % figure number
1     % blue


%% Data file for snapshot solution of Boussinesq demo problem 

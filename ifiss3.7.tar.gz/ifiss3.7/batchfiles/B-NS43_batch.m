2     % problem
8     % H
1     % L
2     % stretched grid 
31    % number of elements in x-direction
8     % multiplication factor
2     % x-direction stretch factor
1     % y-direction stretch factor
1     % node enumeration
1     % adiabatic temperature BC
3.4e5 % Ra
0.71  % Pr
80    % target time
5     % nmax (9000 time steps)
3e-5  % time accuracy tolerance
0     % number of Picard steps
9     % time averaging frequency
1     % solution plot switch
5     % plotting frequency
16    % frame rate
0.5   % profile x coordinate
4.0   % profile y coordinate
1     % generate point history 
0.181 % x1
7.370 % y1
0.819 % x2
7.370 % y2 
13    % timestep evolution figure number

%% Data file for test problem 4.3 (MIT)  

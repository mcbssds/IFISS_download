1     % problem
1     % H
8     % L
1     % uniform grid 
20    % number of elements in y-direction
8     % multiplication factor
2     % node enumeration
1     % adiabatic temperature BC
1.5e4 % Ra
7.1   % Pr
300   % target time
5     % nmax (200 time steps)
1e-5  % 1e-6 time accuracy tolerance
0     % number of Picard steps
9     % time averaging frequency
1     % solution plot switch
5     % plotting frequency
16    % frame rate
0.5   % profile y coordinate
1     % generate point history 
0.2   % x1
0.2   % y1
0.2   % x2
0.8   % y2 
13    % timestep evolution figure number

%% Data file for test problem 4.1  

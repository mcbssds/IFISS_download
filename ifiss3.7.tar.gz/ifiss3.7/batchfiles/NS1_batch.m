1     % problem
1     % channel length
4     % grid parameter
4     % discretisation
0.01  % viscosity parameter
3     % Picard/Newton/hybrid linearization
2     % number of Picard iterations
4     % number of Newton iterations
1.d-9 % nonlinear tolerance
1     % uniform/exponential streamlines

%% Data file for test problem NS1 

25    % snapshot time
1e-8  % stopping tolerance
30    % maximum number of iterations
3     % LSC preconditioner
2     % AMG
2     % Load AMG data
2     % LSC smoothing on the finest level
0     % existing figure
19    % figure number
7     % black

%% Data file for snapshot solution of Boussinesq demo problem 

2     % problem
5     % outlet length L 
5     % grid parameter
1.3   % stretch factor 
4     % discretisation
0     % Stokes stabilization parameter

%% Data file for test problem S2

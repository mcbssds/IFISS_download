2     % problem
5     % outflow length
6     % grid parameter
1.2   % stretch factor
3     % discretisation
0.02  % viscosity parameter
200   % target time
2     %  number of steps (x200)
3e-5  % time accuracy tolerance
0     % number of Picard steps
10    % time averaging frequency
0     % solution plot switch
13    % timestep evolution figure number

%% Data file for test problem T-NS2 

1     % GMRES
1e-6  % stopping tolerance
100   % maximum number of iterations
4     % Fp* preconditioner
1     % ideal preconditioning
1     % figure number
1     % color 

%% Data file for iterative solution of Oseen problem 

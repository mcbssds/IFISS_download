1     % GMRES
1e-6  % stopping tolerance
130   % maximum number of iterations
2     % Fp preconditioner
2     % AMG
1     % compute AMG data
1     % PDJ smoothing on the finest level
0     % existing figure
1     % figure number
5     % magenta

%% Data file for iterative solution of Oseen problem 

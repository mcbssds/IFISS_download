10    % snapshot time
1e-6  % stopping tolerance
50    % maximum number of iterations
4     % PCD* preconditioner
2     % AMG
1     % PDJ smoothing on the finest level
0     % existing figure
1     % figure number
7     % black

%% Data file for snapshot solution of NS demo problem 

3     % problem
3     % cavity type
5     % grid parameter
2     % uniform/stretched grid
3     % discretisation
2     % uniform/exponential streamlines

%% Data file for test problem S3

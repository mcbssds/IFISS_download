1     % GMRES
1e-6  % stopping tolerance
100   % maximum number of iterations
4     % Fp* preconditioner
2     % AMG
1     % compute AMG data
2     % ILU smoothing on the finest level
0     % existing figure
1     % figure number
7     % black

%% Data file for iterative solution of Oseen problem 

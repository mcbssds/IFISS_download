4     % problem
5     % grid parameter
1     % grid stretch factor
2     % discretisation
0.02  % viscosity parameter
3     % Picard/Newton/hybrid linearization
2     % number of Picard iterations
4     % number of Newton iterations
1.d-5 % nonlinear tolerance
0.25  % Stokes stabilization parameter

%% Data file for test problem NS4

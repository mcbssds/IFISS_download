4     % problem
4     % grid parameter
1     % uniform/stretched grid
2     % discretisation
0.25  % Stokes stabilization parameter
1     % uniform/exponential streamlines

%% Data file for test problem S4

4     % problem
0     % no regularisation
7     % grid parameter
1     % uniform/stretched grid
0.02  % viscosity parameter
inf   % SUPG parameter (inf==>optimal)

%% Data file for test problem CD4

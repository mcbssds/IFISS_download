2     % problem
4     % grid parameter
1     % uniform/stretched/shishkin grid
1     % outflow boundary
0.005 % viscosity parameter
inf   % SUPG parameter (inf==>optimal)

%% Data file for test problem CD2

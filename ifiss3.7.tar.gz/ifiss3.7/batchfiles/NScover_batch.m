2     % problem
5     % outlet length L 
6     % grid parameter
1.15  % stretch factor 
4     % discretisation
0.02  % viscosity parameter
3     % Picard/Newton/hybrid linearization
2     % number of Picard iterations
4     % number of Newton iterations
1e-8  % nonlinear tolerance
1     % uniform/exponential streamlines
120   % number of streamlines

%% Data file for test problem NS2 

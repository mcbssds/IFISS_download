3     % problem
3     % cavity type
6     % grid parameter
2     % stretched grid
3     % discretisation
0.005 % viscosity parameter
1e4   % target time
2     %  number of steps (x200)
3e-5  % time accuracy tolerance
0     % number of Picard steps
10    % time averaging frequency
0     % 0 solution plot switch
14    % timestep evolution figure number

%% Data file for test problem T-NS3 

4     % problem
4     % grid parameter
1     % grid stretch factor
1     % approximation

%% Data file for test problem P4
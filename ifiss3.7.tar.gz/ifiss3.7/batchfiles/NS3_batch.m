3     % problem
3     % cavity type
5     % grid parameter
1     % uniform/stretched grid
3     % discretisation
0.02  % viscosity parameter
3     % Picard/Newton/hybrid linearization
2     % number of Picard iterations
4     % number of Newton iterations
1.d-5 % nonlinear tolerance
2     % uniform/exponential streamlines

%% Data file for test problem NS3

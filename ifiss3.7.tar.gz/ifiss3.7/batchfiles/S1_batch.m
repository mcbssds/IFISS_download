1     % problem
1     % channel length
4     % grid parameter
2     % discretisation
0.25  % Stokes stabilization parameter
1     % uniform/exponential streamlines

%% Data file for test problem S1 

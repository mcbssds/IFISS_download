6%
16%
5%
1%
4%
0.0045%
1e-16%
1e15%
6%
3e-6%
2%
2500%
0%
13%
%---------- data file for symmetric step test problem

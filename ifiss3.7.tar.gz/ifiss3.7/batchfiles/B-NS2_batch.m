3     % problem
20    % outflow length
5     % grid parameter
1.3   % stretch factor
17750 % Ra
7.1   % Pr
100   % target time
1     % nmax (200 time steps)
3e-4  % time accuracy tolerance
0     % number of Picard steps
10    % time averaging frequency
1     % solution plot switch
4     % plotting frequency
8     % frame rate
10    % x coordinate
0     % generate point history 
13    % timestep evolution figure number

%% Data file for test problem B-NS2 

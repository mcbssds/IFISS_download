function batchprocess(testproblem)
%BATCHPROCESS enables parallel batch processing for IFISS testproblem
%   batchprocess(testproblem);
%   input
%          testproblem  character string naming the testproblem
%                       must have the form "*_batch".m where "*" begins with
%                       "T-NS"    for unsteady flow problems
%                       "B-NS"    for Boussinesq flow problems
%   side effect
%          If batchmode terminates prematurely because of an error or
%          execution of cntl-C, interactive input with IFISS may not
%          work correctly.  This is fixed by typing "activemode".
%
%
%   IFISS function: HCE, DJS; 8 October 2025.
% Copyright (c) 2005 D.J. Silvester, H.C. Elman, A. Ramage

global BATCH FID DELTA bsn
% file containing input data
batchfile=[testproblem,'_batch.m'];
[FID,message]=fopen(batchfile,'r');
% Error return on nonexistent or misnamed input file
if strcmp(message,'')~=1
   error(['INPUT FILE ERROR: ' message])
else
   disp(['Working in batch mode from data file ' batchfile])
end
if ~(strncmp(testproblem,'T-NS',4) |  strncmp(testproblem,'B-NS',4)),
    errmsg = 'INPUT FILE ERROR:\n';
    errmsg = [errmsg,'   Batch input filenames must have the form "*_batch.m"'];
    errmsg = [errmsg,' where "*" begins with\n'];
    errmsg = [errmsg,'   "T-NS" for generation of unsteady flow problems\n'];
    errmsg = [errmsg,'   "B-NS"  for generation of Boussinesq flow problems\n'];
    error('BATCH:err',errmsg);    
end  

% run appropriate driver
if strncmp(testproblem,'T-NS',4)
%   unsteady_navier_testrun
%   gohome, cd datafiles, save unsteadyrun.mat
   elseif strncmp(testproblem,'B-NS',4)
   problemstring=string(batchfile);
   testctr=extractBetween(problemstring,"test","_batch");
   testk=convertStringsToChars(testctr); test=str2num(testk);
   fprintf('\n\nBoussinesq flow in a cavity domain ... test %g.\n',test)
%----------- input parameters
   Ra=defaultX('Rayleigh number (default 3.4e5)',3.4e5);
   Pr=defaultX('Prandtl number (default 0.71)',0.71);
   delta=defaultX('temperature perturbation magnitude',0);
   DELTA=delta;
   tfinal = defaultX('target time? (default 100)',100);
   nmax = defaultX('number of timesteps (x200)? (default 5)',5);
   tol = defaultX('accuracy tolerance? (default 3e-5)',3e-5);
   nonlin = defaultX('number of nonlinear Picard correction steps?',0);
   nstar = defaultX('averaging frequency? (default 10)',10);
   vswitch = defaultX('plot solution evolution? 1/0',0);
   xout = defaultX('generate solution history data points? 1/0',0);
   tout = xout+1; tout=0;
   dtzero=1e-9;
%
%----------- unpack grid data
   gohome; cd datafiles;
   load rect_bouss_nobc.mat;
   load rect_grid1h.mat; 
   xyv=gridx(1).xyv;  [nnv,dd]=size(xyv(:,1));
   xyp=gridx(1).xyp;  [nnp,dd]=size(xyp(:,1));
   xyt=gridx(1).xyt;  [nnt,dd]=size(xyt(:,1));
   uzero=zeros(2*nnv,1); gzero=zeros(nnp,1);
   hzero=zeros(nnt,1);
%----------- pack start data
   initdata=struct('uzero',uzero,'ttzero',hzero, ...
                'dtzero',dtzero,'restart',0);
%
%----------- compute solution
   [DT,time,KE,VTY] = stabtrBoussX(test,Pr,Ra,H,L, ...
            nonlin,qmethod,gridx,spmat,initdata,tfinal,tol,nstar,nmax,tout);
  
%------- save results in appropriate file structure
   s = struct("Ra",Ra,"Pr",Pr,"delta",delta,...
              "DT",DT,"time",time,"KE",KE,"VTY",VTY);
   testresults=['Bouss_output',testk]
   gohome, cd datafiles, save(testresults,"-fromstruct",s);
   fprintf('Solution data saved for test %g\n',test)
   end
fclose(FID);
return

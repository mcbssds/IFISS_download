3     % problem
1     % cavity type
6     % grid parameter
2     % uniform/stretched grid
3     % discretisation
0.005 % viscosity parameter
3     % Picard/Newton/hybrid linearization
2     % number of Picard iterations
4     % number of Newton iterations
1.e-8 % nonlinear tolerance
2     % uniform/exponential streamlines

%% Data file for test problem NS3

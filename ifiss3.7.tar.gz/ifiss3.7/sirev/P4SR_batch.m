4     % problem
4     % grid parameter
1.5   % grid stretch factor
1     % approximation

%% Data file for test problem P4 with stretched grid

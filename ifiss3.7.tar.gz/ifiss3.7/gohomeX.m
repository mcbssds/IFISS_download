%GOHOME positions command prompt at top level directory
%   IFISS scriptfile: DJS; 9 January 2019.
% Copyright (c) 2005 D.J. Silvester, H.C. Elman, A. Ramage (see readme.m)
cd('/mnt/iusers01/maths01/mcbssds/scratch/ifiss3.7')
%cd('/home/caas63/ifiss3.7');
%cd('/fs/helios/elman/ifiss/ifiss3.7');
%cd('c:\Documents and Settings\elman\My Documents\MATLAB\ifiss3.7');

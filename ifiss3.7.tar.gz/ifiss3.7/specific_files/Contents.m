% SPECIFIC_FILES
%
% Files
%   install_pc                       - sets up IFISS on non-UNIX computer
%   install_unix                     - sets up IFISS on UNIX computer
%   install_windows                  - sets up windows version of IFISS on UNIX computer

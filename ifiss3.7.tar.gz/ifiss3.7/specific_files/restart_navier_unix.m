%RESTART_CHANNEL_NAVIER restart unsteady flow in channel domain
%   s-IFISS scriptfile: DJS; 20 September 2016.
% Copyright (c) 2014 D.J. Silvester, H.C. Elman
% Modified (c) 2023 M.D. Mihajlovic
clear all; close all
global pde viscosity

fprintf('Navier-Stokes flow in channel domain ... \n')
fprintf('Restarting integration from Checkpoint datafile ...\n')
% load data from original integration
gohome, cd datafiles
load square_unsteadyflow.mat
load stabtrNS_end.mat
fprintf('viscosity parameter is  %11.3e\n',viscosity)
restart=initdata.restart;
dt=initdata.dt; tbegin=initdata.time;
n=length(dt)-1; oldDT=DT;
dt0=initdata.dt0;
u=initdata.u;

% load assembled matrices
gohome, cd datafiles
load square_stokes_nobc.mat

% initialize for time stepping iteration
fprintf('restarting from %11.3e seconds\n',tbegin)
%% set parameters
pde=14; domain=1;
tfinal = default('new final time? (1e14)',1e14);
nmax = default('number of timesteps (x200)? (default 5)',5); %% 5 | 1000 timesteps
tol = default('accuracy tolerance? (default 3e-5)',3e-5);
nonlin = default('number of Picard steps? (default 1)',1);
nstar = default('averaging frequency? (default 10)',10);
vswitch = default('plot solution evolution? 1/0',0);
if(vswitch==1)
   vfreq=default('plotting frequency (default every 10 time steps)',10);
   fps=default('movie frame rate [fps] (default 16)',16);
   xc=default('x coordinate for the horisontal velocity profile (default 0)',0);
   if(xc<-1 || xc>1)
      error('x coordinate outside of the domain');
      return
   end
   xr=x-xc;
   [xmin,ix]=min(abs(xr));
   xref=x(ix);
   yc=default('y coordinate for the vertical velocity profile (default 0)',0);
   if(yc<-1 || yc>1)
      error('y coordinate outside of the domain');
      return
   end
   yr=y-yc;
   [ymin,iy]=min(abs(yr));
   yref=y(iy);
end
gzero=zeros(size(g));
%% compute solution
tstart = tic;
np=length(g); 
AxB='defaultAxB';
[DT,U,Udot,xtime] = stabtrNS(qmethod,xy,mv,bound,A,B,sparse(np,np),G,AxB,...  %%%%%%%%%
                                u,dt0,tfinal,tol,nstar,1,nonlin,nmax,restart);
etoc=toc(tstart); fprintf('Integration took  %8.3e seconds\n\n',etoc) 
save square_unsteadyflow.mat DT U Udot time viscosity
clear U Udot
% visualise solution and hold the timestep sequence plot
marker = 'k.'; offset=0;
dttplot(oldDT(1:end-1),99,marker,offset)
marker = 'r.'; 
dttplot(DT,99,marker,length(oldDT)-1)
pause(2)
%
%  visualise solution
if(vswitch==1)
   fprintf('\nGenerating movies ... \n');
   uvid=VideoWriter('VelocityMovie.mp4','MPEG-4');             %  velocity video file
   uvid.FrameRate=fps; uvid.Quality=100;                       %  velocity video fps/quality
   vvid=VideoWriter('VorticityMovie.mp4','MPEG-4');            %  vorticity video file
   vvid.FrameRate=fps; vvid.Quality=100;                       %  vorticity video fps/quality
   uxpvid=VideoWriter('xVelocityProfileMovie.mp4','MPEG-4');   %  x-velocity profile video file
   uxpvid.FrameRate=fps; uxpvid.Quality=100;                   %  x-velocity video fps/quality
   uypvid=VideoWriter('yVelocityProfileMovie.mp4','MPEG-4');   %  y-velocity profile video file
   uypvid.FrameRate=fps; uypvid.Quality=100;                   %  y-velocity video fps/quality
   open(uvid);                                     %  open velocity video file
   open(vvid);                                     %  open vorticity video file
   open(uxpvid);                                   %  open x-velocity profile video file
   open(uypvid);                                   %  open y-velocity profile video file
   load('MovieSegments.mat');                      %  number of segments in krestart
   load('VelocityScaling.mat');                    %  maximum x and y velocities    
   for i=1:krestart
      fname=sprintf('%s%i','MovieData',i);         %  filename of a segment
      load(fname);
      sseg=length(soltime);                        %  number of time steps in a segment
      fprintf('   Segment %i: Time steps %i to %i\n',i,(i-1)*200+1,(i-1)*200+sseg);
      square_unsteadyflowref(qmethod,U,soltime,mv,By,Bx,A,G,xy,xyp,x,y,bound,...
                             xref,yref,i,krestart,vfreq,uvid,vvid,uxpvid,uypvid,uxmax,uxmin,uymax,uymin)
       %%% compute the divergence error  
      if qmethod>1
         error_div = q2div(xy,mv,[U(:,end);gzero]);
      else
         error_div = q1div(xy,ev,[U(:,end);gzero]);
      end
      % compute mean quantities
      [ke,acc,meanv] = energymeanvorticity(qmethod,mv,U,Udot,soltime,By,Bx,G,xy,1,101,(i-1)*200);
      clear U Udot soltime
   end
   close(uvid);     %  close velocity video file
   close(vvid);     %  close vorticity video file
   close(uxpvid);   %  close x-velocity profile video file
   close(uypvid);   %  close y-velocity profile video file
end
fprintf('All done\n')
delete('VelocityScaling.mat');
return

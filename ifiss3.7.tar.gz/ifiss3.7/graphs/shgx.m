%SHGX switch colormap for enhanced visual display
%IFISS scriptfile: DJS; 9 January 2019.
%Copyright (c) 2019 D.J. Silvester, H.C. Elman, A. Ramage
shg
colormap('jet')

%PLOT_BOUSSDATA plots snapshot Boussinesq flow solution
%   IFISS scriptfile: DJS;  14 October 2025.
% Copyright (c) 2012 D.J. Silvester, M.L. Mihajlovic

% insist on enclosed flow domain
if domain~=7,error('Plotting is not possible on a non-rectangular domain.'), end;
fprintf('Plotting Boussinesq flow in a rectangular domain...\n')
figno = default('Figure number for streamline SNAPSHOT? (default 11)',11);

%% load assembled matrices
gohome;
cd datafiles;
load rect_bouss_nobc.mat; load rect_grid1h.mat
%

%%% unpack grid and matrix data
tout=1;unpack_boussdataX
boundv=bnd_d; boundt=bnd_dn2;
%
%


%% unpack grid data
xyv=gridx(1).xyv;  nvtx=length(xyv);
xyp=gridx(1).xyp;  np=length(xyp);
xyt=gridx(1).xyt;  nt=length(xyt);
%
%% streamfunction
Asv=spmat.Av(1:nvtx,1:nvtx);
f=[spmat.BBy,-spmat.BBx]*u; 
[Asv,fsv]=zerobc(Asv,f,xyv,boundv);
phi=Asv\fsv;
figure(figno)
[X,Y]=meshgrid(gridx.x,gridx.y);
xysol=griddata(xyv(:,1),xyv(:,2),phi,X,Y);
%list=[-9.507,[-8.646:8.646/9:0]];
%contour(X,Y,xysol,list),axis('image');
contour(X,Y,xysol,12),axis('image');
title(['Velocity streamlines'],'FontSize',12);
boxz, axis('off')
%% isotherms
figure(figno-10)
xysolt = griddata(xyt(:,1),xyt(:,2),tt,X,Y);
contour(X,Y,xysolt,25),axis('image');
boxx, axis('off')

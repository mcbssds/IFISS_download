%helpme_ch4    helpme  for Chapter 4/7 specialized functions
%  IFISS scriptfile: DJS; 29 September 2013.

fprintf(' \n');
fprintf(' The files in the directory solvers/ch4_code can be used to reproduce \n');
fprintf(' results from Chapter 4 of the first edition of the Elman-Silvester-Wathen monograph.\n');
fprintf(' Type "help ch4_code" for details.\n');
fprintf(' \n');